import json
from django.contrib.auth.hashers import check_password, make_password
from django.db import IntegrityError, transaction
from django.http import JsonResponse
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from .models import (
    ChwAssignments,
    ClinicStaff,
    Clinics,
    ElderlyClinic,
    ElderlyProfiles,
    FamilyElderly,
    Users,
)


ALLOWED_ROLES = {"admin", "family", "elderly", "chw", "clinic"}


def _method_not_allowed(allowed):
    return JsonResponse(
        {"error": f"Method not allowed. Use {', '.join(allowed)}."},
        status=405,
    )


def _read_json(request):
    try:
        payload = json.loads(request.body or b"{}")
    except (json.JSONDecodeError, UnicodeDecodeError):
        return None, JsonResponse({"error": "Invalid JSON"}, status=400)
    if not isinstance(payload, dict):
        return None, JsonResponse({"error": "JSON body must be an object"}, status=400)
    return payload, None


def _id_from(payload, key):
    value = payload.get(key)
    if value in (None, ""):
        return None
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return None
    return parsed if parsed > 0 else None


def _get_role_user(user_id, role):
    if user_id is None:
        return None
    return Users.objects.filter(user_id=user_id, role=role).first()


def _user_data(user):
    return {
        "user_id": user.user_id,
        "full_name": user.full_name,
        "phone": user.phone,
        "role": user.role,
    }


def _age_from_date_of_birth(dob):
    if not dob:
        return None
    today = timezone.localdate()
    return today.year - dob.year - ((today.month, today.day) < (dob.month, dob.day))


def users_api(request):
    if request.method != "GET":
        return _method_not_allowed(["GET"])

    users = Users.objects.all().order_by("full_name", "user_id")
    return JsonResponse([_user_data(user) for user in users], safe=False)


@csrf_exempt
def register_api(request):
    if request.method != "POST":
        return _method_not_allowed(["POST"])

    body, error = _read_json(request)
    if error:
        return error

    full_name = str(body.get("full_name") or "").strip()
    phone = str(body.get("phone") or "").strip()
    password = str(body.get("password") or "")
    role = str(body.get("role") or "").strip().lower()

    if not full_name or not phone or not password or not role:
        return JsonResponse({"error": "All fields are required"}, status=400)
    if role not in ALLOWED_ROLES:
        return JsonResponse({"error": "Invalid user role"}, status=400)
    if Users.objects.filter(phone=phone).exists():
        return JsonResponse({"error": "Phone number already registered"}, status=400)

    try:
        user = Users.objects.create(
            full_name=full_name,
            phone=phone,
            password=make_password(password),
            role=role,
        )
    except IntegrityError:
        return JsonResponse({"error": "Phone number already registered"}, status=400)

    return JsonResponse(
        {"message": "User registered successfully", **_user_data(user)},
        status=201,
    )


@csrf_exempt
def login_api(request):
    if request.method != "POST":
        return _method_not_allowed(["POST"])

    body, error = _read_json(request)
    if error:
        return error

    phone = str(body.get("phone") or "").strip()
    password = str(body.get("password") or "")
    if not phone or not password:
        return JsonResponse(
            {"error": "Phone number and password are required"}, status=400
        )

    user = Users.objects.filter(phone=phone).first()
    if not user or not check_password(password, user.password):
        return JsonResponse(
            {"error": "Invalid phone number or password"}, status=401
        )

    return JsonResponse({"message": "Login successful", **_user_data(user)})


@csrf_exempt
def family_elderly_api(request):
    if request.method == "GET":
        records = FamilyElderly.objects.select_related(
            "family_user", "elderly_user"
        ).order_by("family_user__full_name", "elderly_user__full_name")
        family_user_id = request.GET.get("family_user_id")
        elderly_user_id = request.GET.get("elderly_user_id")
        if family_user_id:
            records = records.filter(family_user_id=family_user_id)
        if elderly_user_id:
            records = records.filter(elderly_user_id=elderly_user_id)

        data = [{
            "family_user_id": item.family_user_id,
            "family_name": item.family_user.full_name,
            "elderly_user_id": item.elderly_user_id,
            "elderly_name": item.elderly_user.full_name,
            "relationship_type": item.relationship_type,
        } for item in records]
        return JsonResponse(data, safe=False)

    if request.method != "POST":
        return _method_not_allowed(["GET", "POST"])

    body, error = _read_json(request)
    if error:
        return error
    family_id = _id_from(body, "family_user_id")
    elderly_id = _id_from(body, "elderly_user_id")
    if not family_id or not elderly_id:
        return JsonResponse(
            {"error": "Family member and elderly user are required"}, status=400
        )
    family = _get_role_user(family_id, "family")
    elderly = _get_role_user(elderly_id, "elderly")
    if not family or not elderly:
        return JsonResponse(
            {"error": "Selected users must exist and have family and elderly roles"},
            status=400,
        )

    try:
        with transaction.atomic():
            FamilyElderly.objects.create(
                family_user=family,
                elderly_user=elderly,
                relationship_type=str(body.get("relationship_type") or "").strip() or None,
            )
    except IntegrityError:
        return JsonResponse(
            {"error": "This family member and elderly user are already connected"},
            status=400,
        )
    return JsonResponse({
        "message": "Family member connected to elderly user successfully",
        "family_user_id": family.user_id,
        "elderly_user_id": elderly.user_id,
    }, status=201)


@csrf_exempt
def clinics_api(request):
    if request.method == "GET":
        clinics = Clinics.objects.all().order_by("clinic_name", "clinic_id")
        return JsonResponse([{
            "clinic_id": clinic.clinic_id,
            "clinic_name": clinic.clinic_name,
            "address": clinic.address,
            "phone": clinic.phone,
            "status": clinic.status or "active",
        } for clinic in clinics], safe=False)

    if request.method != "POST":
        return _method_not_allowed(["GET", "POST"])

    body, error = _read_json(request)
    if error:
        return error
    clinic_name = str(body.get("clinic_name") or "").strip()
    address = str(body.get("address") or "").strip()
    phone = str(body.get("phone") or "").strip()
    if not clinic_name or not address or not phone:
        return JsonResponse(
            {"error": "Clinic name, address, and phone are required"}, status=400
        )

    clinic = Clinics.objects.create(
        clinic_name=clinic_name,
        address=address,
        phone=phone,
        status="active",
    )
    return JsonResponse({
        "message": "Clinic registered successfully",
        "clinic_id": clinic.clinic_id,
        "clinic_name": clinic.clinic_name,
        "address": clinic.address,
        "phone": clinic.phone,
        "status": clinic.status,
    }, status=201)


@csrf_exempt
def chw_assignments_api(request):
    if request.method == "GET":
        assignments = ChwAssignments.objects.select_related(
            "chw_user", "elderly_user"
        ).order_by("elderly_user__full_name")
        chw_user_id = request.GET.get("chw_user_id")
        if chw_user_id:
            assignments = assignments.filter(chw_user_id=chw_user_id)

        profiles = {
            profile.user_id: profile
            for profile in ElderlyProfiles.objects.filter(
                user_id__in=[item.elderly_user_id for item in assignments]
            )
        }
        data = []
        for item in assignments:
            profile = profiles.get(item.elderly_user_id)
            data.append({
                "assignment_id": item.assignment_id,
                "chw_user_id": item.chw_user_id,
                "chw_name": item.chw_user.full_name,
                "elderly_user_id": item.elderly_user_id,
                "elderly_name": item.elderly_user.full_name,
                "assignment_date": item.assignment_date.isoformat() if item.assignment_date else None,
                "status": item.status or "active",
                "address": profile.address if profile else "",
                "age": _age_from_date_of_birth(profile.date_of_birth) if profile else None,
            })
        return JsonResponse(data, safe=False)

    if request.method != "POST":
        return _method_not_allowed(["GET", "POST"])

    body, error = _read_json(request)
    if error:
        return error
    chw_id = _id_from(body, "chw_user_id")
    elderly_id = _id_from(body, "elderly_user_id")
    chw = _get_role_user(chw_id, "chw")
    elderly = _get_role_user(elderly_id, "elderly")
    if not chw or not elderly:
        return JsonResponse(
            {"error": "Selected users must exist and have CHW and elderly roles"},
            status=400,
        )
    try:
        with transaction.atomic():
            assignment = ChwAssignments.objects.create(
                chw_user=chw,
                elderly_user=elderly,
                assignment_date=timezone.localdate(),
                status="active",
            )
    except IntegrityError:
        return JsonResponse(
            {"error": "This CHW and elderly user are already connected"}, status=400
        )
    return JsonResponse({
        "message": "CHW connected to elderly user successfully",
        "assignment_id": assignment.assignment_id,
        "chw_user_id": chw.user_id,
        "elderly_user_id": elderly.user_id,
    }, status=201)


@csrf_exempt
def elderly_clinics_api(request):
    if request.method == "GET":
        assignments = ElderlyClinic.objects.select_related(
            "elderly_user", "clinic"
        ).order_by("elderly_user__full_name", "clinic__clinic_name")
        data = [{
            "elderly_clinic_id": item.elderly_clinic_id,
            "elderly_user_id": item.elderly_user_id,
            "elderly_name": item.elderly_user.full_name,
            "clinic_id": item.clinic_id,
            "clinic_name": item.clinic.clinic_name,
            "assigned_date": item.assigned_date.isoformat() if item.assigned_date else None,
            "status": item.status or "active",
        } for item in assignments]
        return JsonResponse(data, safe=False)

    if request.method != "POST":
        return _method_not_allowed(["GET", "POST"])

    body, error = _read_json(request)
    if error:
        return error
    elderly_id = _id_from(body, "elderly_user_id")
    clinic_id = _id_from(body, "clinic_id")
    elderly = _get_role_user(elderly_id, "elderly")
    clinic = Clinics.objects.filter(clinic_id=clinic_id).first() if clinic_id else None
    if not elderly or not clinic:
        return JsonResponse(
            {"error": "Select an existing elderly user and clinic"}, status=400
        )
    try:
        with transaction.atomic():
            assignment = ElderlyClinic.objects.create(
                elderly_user=elderly,
                clinic=clinic,
                assigned_date=timezone.localdate(),
                status="active",
            )
    except IntegrityError:
        return JsonResponse(
            {"error": "This elderly user is already connected to that clinic"},
            status=400,
        )
    return JsonResponse({
        "message": "Elderly user connected to clinic successfully",
        "elderly_clinic_id": assignment.elderly_clinic_id,
        "elderly_user_id": elderly.user_id,
        "clinic_id": clinic.clinic_id,
    }, status=201)


@csrf_exempt
def clinic_staff_api(request):
    if request.method == "GET":
        assignments = ClinicStaff.objects.select_related(
            "staff_user", "clinic"
        ).order_by("staff_user__full_name", "clinic__clinic_name")
        data = [{
            "staff_id": item.staff_id,
            "staff_user_id": item.staff_user_id,
            "staff_name": item.staff_user.full_name,
            "clinic_id": item.clinic_id,
            "clinic_name": item.clinic.clinic_name,
            "position": item.position,
            "status": item.status or "active",
        } for item in assignments]
        return JsonResponse(data, safe=False)

    if request.method != "POST":
        return _method_not_allowed(["GET", "POST"])

    body, error = _read_json(request)
    if error:
        return error
    staff_id = _id_from(body, "staff_user_id")
    clinic_id = _id_from(body, "clinic_id")
    staff = _get_role_user(staff_id, "clinic")
    clinic = Clinics.objects.filter(clinic_id=clinic_id).first() if clinic_id else None
    if not staff or not clinic:
        return JsonResponse(
            {"error": "Select an existing clinic staff user and clinic"}, status=400
        )
    try:
        with transaction.atomic():
            assignment = ClinicStaff.objects.create(
                staff_user=staff,
                clinic=clinic,
                position=str(body.get("position") or "").strip() or None,
                status="active",
            )
    except IntegrityError:
        return JsonResponse(
            {"error": "This staff member is already connected to that clinic"},
            status=400,
        )
    return JsonResponse({
        "message": "Clinic staff connected to clinic successfully",
        "staff_id": assignment.staff_id,
        "staff_user_id": staff.user_id,
        "clinic_id": clinic.clinic_id,
    }, status=201)
