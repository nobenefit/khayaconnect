from django.contrib import admin
from django.urls import path

from core.views import (
    users_api,
    register_api,
    login_api,
    family_elderly_api,
    clinics_api,
    chw_assignments_api,
    elderly_clinics_api,
    clinic_staff_api,
)

urlpatterns = [
    path("admin/", admin.site.urls),

    path("api/users/", users_api),
    path("api/register/", register_api),
    path("api/login/", login_api),

    path("api/family-elderly/", family_elderly_api),
    path("api/clinics/", clinics_api),
    path("api/chw-assignments/", chw_assignments_api),
    path("api/elderly-clinics/", elderly_clinics_api),
    path("api/clinic-staff/", clinic_staff_api),
]
